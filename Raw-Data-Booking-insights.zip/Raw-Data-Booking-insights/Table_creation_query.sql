-- Creating an user_table, with user_id as the PRIMARY KEY.

CREATE TABLE user_table (
  `User_id` VARCHAR(25) NOT NULL,
  `Segment` VARCHAR(25) NULL,
  PRIMARY KEY (`User_id`));


/*Creating a booking_table with booking_id as the PRIMARY KEY, and 
user_id as a FOREIGN KEY, referencing the user_table. */

CREATE TABLE booking_table (
Booking_id VARCHAR(25),
Booking_date DATE,
User_id VARCHAR(25),
Line_of_business VARCHAR(25),
PRIMARY KEY (Booking_id),
FOREIGN KEY (user_id) REFERENCES user_table(user_id)
);

